Instructions on how to run:
1. For running frontend:
- Go to /frontend
- run "docker compose build --no-cache" followed by "docker compose up"

2. For running backend:
- Go to /backend_compiled/backend/model
- run "docker compose build --no-cache" followed by "docker compose up"

viola !! both docker containers must be running and you can check out the website at localhost:3000 (usual) or url mentioned in frontend logs

Check the user manual for guidelines - first click on register, register user and then login into the website
