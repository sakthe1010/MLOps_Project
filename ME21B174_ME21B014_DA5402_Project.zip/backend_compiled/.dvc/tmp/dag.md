```mermaid
flowchart TD
	node1["backend\airflow\dags\ncert_pdfs.dvc"]
	node2["preprocess"]
	node3["split"]
	node4["train"]
	node1-->node2
	node2-->node3
	node3-->node4
	node5["backend\airflow\dags\ncert_content.db.dvc"]
	node6["backend\airflow\dags\ncert_dataset.jsonl.dvc"]
```